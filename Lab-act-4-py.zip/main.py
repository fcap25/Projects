def matches(nums1,nums2):
  list = []
  bool = False
  for x in range(len(nums1)):
    if(nums1[x] == nums2[x]):
      list.append(True)
    else:
      list.append(False)
  return list

def flatten(list):
    acc = []
    for i in range(len(list)):
        for j in range(len(list[i])):
            acc.append(list[i][j])
    return acc

print(flatten([ ]))
print(flatten([ [4.5] ]))
print(flatten([ [4.5, 5.3] ]))
print(flatten([[4.5,5.3],[-2.3],[1.2,-9.0,100]]))
print(matches([4,1,2,3],[4,2,2,4,5]))
print(matches([4,1,2,3],[4,1,2,3]))