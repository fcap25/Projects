import csv
import datetime

def readCSV(filename):
  retval = []
  with open(filename,'r',newline='',encoding="utf-8") as csvFile:
    reader = csv.DictReader(csvFile)
    for row in reader:
      retval.append(row)
  return retval
     
ALL_DATA = readCSV("311_Service_Requests_small.csv")

def writeCSV(filename, dicts):
  with open(filename,'w',newline='') as csvFile:
    writer = csv.writer(csvFile)
    keys = dicts[0].keys()
    writer.writerow(keys)
    for dict in dicts:
      writer.writerow(dict.values())

def keepOnly(dicts,key,value):
  retval = []
  for dict in dicts:
    if(key,value) in dict.items():
      retval.append(dict)
  return retval

def discardOnly(dicts,key,value):
  retval = []   
  for dict in dicts:
    if not (key, value) in dict.items():
      retval.append(dict)
  return retval

def filterRange(dicts,key,low,high):
  retval = []
  for dict in dicts:
    if dict.get(key) == None:
      dicts.remove(dict)
    elif low <= dict[key] and dict[key] < high:
      retval.append(dict)
  return retval

def duration(date1,date2):
  diff = date2 - date1
  diff
  datetime.timedelta(days=0)
  return diff.days

def departments(list_of_dictionaries):
  retval = []
  for x in list_of_dictionaries:
    subject = x["SUBJECT"]
    if not subject in retval:
      retval.append(subject)
  retval.sort()
  return retval

def open_year(dictionary):
  date = dictionary["OPEN DATE"]
  year = date[6:10]
  return year

def filterYear(list_of_dictionaries, low, high):
  retval = []
  for d in list_of_dictionaries:
    if int(low) <= int(open_year(d)) and int(open_year(d)) < int(high):
      retval.append(d)
  return retval

def date(string):
  day = int(string[0:2])
  month = int(string[3:5])
  year = int(string[6:10])
  return datetime.date(year, day, month)

def data_by_subject(dict):
  retval = []
  gDepartments = departments(ALL_DATA)
  yearStart = int(dict['year_start'])
  yearEnd = int(dict['year_end'])
  count = 0
  for x in range(yearStart,yearEnd+1):
    values = []
    y = filterYear(ALL_DATA,x,x+1)
    if len(y) == 0:
      continue
    else: 
      totalCount = len(y)
      for d in gDepartments:
        z = keepOnly(y,"SUBJECT",d)
        if len(z) == 0:
          continue
        else:
          dCount = len(z)
          val = int( 100*round(dCount/totalCount, 2))
          values.append(val)
    layout = {
    "values": values,
    "labels": gDepartments,
    "domain": {"column": count},
    "name": str(x),
    "hole": .4,
    "type": 'pie'
    }
    retval.append(layout)
    count += 1
  return retval

def data_by_subject_duration(dict):
  retval = []
  xSeries = []
  year = dict['year']
  count = 0
  requests = filterYear(ALL_DATA,year,int(year)+1)
  gDepartments = departments(ALL_DATA)
  for d in gDepartments:
     dFilter = keepOnly(requests,"SUBJECT",d)
     for x in dFilter:
      openDate = date(x['OPEN DATE'])
      if x['CLOSED DATE'] == '':
        continue
      else:
        closedDate = date(x['CLOSE DATE'])
      dur = duration(openDate,closedDate) 
      y = []
      for i in range(dur+1):
        xSeries.append(i)
  retval.append(({"x": [0,1,2,3,4,5,6,7,8],"y": [],"name": d,"mode": 'markers', "type": 'scatter'}))
  return retval
 
    
print(data_by_subject_duration({ "year": 2004 }))