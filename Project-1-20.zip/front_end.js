'use strict';
function donutHelper(response){
  let data = JSON.parse(response)  
   let s = data[0]["name"]
   let f = data[data.length-1]["name"]
   let layout = {
       title: 'Buffalo Service Requests by Department<br>'+s+" - "+f,
       showlegend: true,
       grid: {rows: 1, columns: data.length}
   };
  Plotly.newPlot('donut', data, layout);
}

function newDonut(){
  let start = document.getElementById("year_start");
  let year_start = start.value;
  let end = document.getElementById("year_end");
  let year_end = end.value;
  start.value = "";
  end.value = "";
  let send = JSON.stringify({"year_start": year_start, "year_end": year_end});
  ajaxPostRequest('/donut',send,donutHelper)
}

function scatterHelper(response){
  let data = JSON.parse(response)
  let year = responseData['year']
   let layout = {
     xaxis: { autorange: true },
     yaxis: { type: 'log', autorange: true },
     title:'Service Request Duration by Department in '+year
   };
}

function newScatter(){
  let s = document.getElementById("year");
  let year = s.value
  s.value = "";
  let send = JSON.stringify({"year": year})
  ajaxPostRequest('/scatter',send,scatterHelper)
}